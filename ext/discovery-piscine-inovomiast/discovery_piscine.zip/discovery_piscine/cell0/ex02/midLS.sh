#!/bin/bash
ls -mptU
